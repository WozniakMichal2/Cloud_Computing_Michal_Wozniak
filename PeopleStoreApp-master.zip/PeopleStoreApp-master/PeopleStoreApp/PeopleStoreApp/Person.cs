﻿namespace PeopleStoreApp
{
    internal class Person
    {
        public Person()
        {
        }
    }
}