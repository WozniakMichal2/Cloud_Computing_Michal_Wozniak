﻿namespace PeopleStoreApp
{
    internal class Plugin
    {
        

        internal class Media
        {
            internal static readonly object CrossMedia;

            internal class Abstractions
            {
                internal class StoreCameraMediaOptions
                {
                }
            }
        }
    }
}