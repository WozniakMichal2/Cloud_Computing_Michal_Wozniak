﻿using System;

namespace PeopleStoreApp
{
    internal class btnPhoto
    {
        public static Action<object, EventArgs> Clicked { get; internal set; }
    }
}